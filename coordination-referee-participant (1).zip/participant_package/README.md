# Coordination Referee — пакет участника

Диагностика сбоёв координации в мультиагентных AI-системах.

По логу запуска команды AI-агентов нужно определить: какой сбой координации
произошёл (7 классов), достигнута ли бизнес-цель и на каком ходу сбой начался.

## Что делать

Реализовать `solution.py`, который платформа запустит так:

```bash
python solution.py --train train.csv --test test.csv --output predictions.csv
```

Обучение и инференс — внутри одного запуска, ≤ 30 минут, без доступа в интернет.

## Первые шаги

```bash
pip install -r requirements.txt

python baseline/solution.py --train data/train.csv --test data/test.csv \
       --output predictions.csv
python scripts/validate_submission.py --pred predictions.csv --test data/test.csv
python scripts/local_cv.py --train data/train.csv --folds 3
```

## Что читать

| Документ | О чём |
|---|---|
| [`docs/task.md`](docs/task.md) | задание целиком: формат ответа, ограничения, примеры сигнала, идеи |
| [`docs/ontology.md`](docs/ontology.md) | точные определения 7 классов — **читать обязательно** |
| [`docs/data_schema.md`](docs/data_schema.md) | поля, JSON-схемы, шум, сдвиг распределения |
| [`docs/metrics.md`](docs/metrics.md) | формула итогового скора |
| [`docs/baseline.md`](docs/baseline.md) | как устроен baseline и где он слаб |

## Содержимое

```
data/train.csv               10 000 ранов с разметкой
data/test.csv                 4 000 ранов без разметки
data/sample_submission.csv    пример формата ответа
docs/                         задание, онтология, схема данных, метрики
baseline/                     рабочий baseline (LightGBM), score 0.717
participant/solution.py       минимальный шаблон решения
scripts/validate_submission.py  проверка формата ответа
scripts/local_cv.py           локальная кросс-валидация по train
evaluation/metrics.py         определения метрик для локальной валидации
requirements.txt              зависимости baseline
```

## Формат ответа

```csv
run_id,label,success,fault_turn
r_e8cbd1c0ed74,clean,1,-1
r_611b6210f9db,deadlock,0,61
```

`label ∈ {clean, dropped_handoff, duplicated_work, deadlock, conflict,
goal_drift, runaway_loop}`, `success ∈ {0,1}`, `fault_turn` — целое (`-1`,
если сбоя нет). Одна строка на каждый `run_id` из `test.csv`.

## Метрика

```
score = 0.50·MacroF1 + 0.25·RobustnessF1 + 0.15·SuccessF1 + 0.10·fault_turn_hit@2
```

Baseline даёт **0.717**. Всё, что выше, — ваш результат.
