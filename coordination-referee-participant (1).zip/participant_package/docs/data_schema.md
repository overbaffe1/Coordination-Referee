# Схема данных

## Файлы

| Файл | Строк | Колонки |
|---|---|---|
| `data/train.csv` | 10 000 | 7 полей рана + `label`, `fault_turn`, `success` |
| `data/test.csv` | 4 000 | только 7 полей рана (public 2 000 + private 2 000, перемешаны) |
| `data/sample_submission.csv` | 4 000 | `run_id,label,success,fault_turn` |


`run_id` в `test.csv` обезличен (`r_<hash>`): по нему нельзя понять, public
это или private.

## Поля рана

Пять полей — JSON-строки, их нужно распарсить (`json.loads`).

### `run_id` (str)
Идентификатор запуска мультиагентной системы.

### `goal` (str)
Бизнес-цель на естественном языке.
Пример: `Close the laptops purchase order for 24 units before the end of Q3`.

### `agents` (JSON list)
```json
[{"id": "a1", "role": "orchestrator", "tools": ["db_query", "web_search"]},
 {"id": "a2", "role": "analyst",      "tools": ["calculator"]}]
```

### `topology` (JSON dict)
```json
{"type": "star", "edges": [["a1", "a2"], ["a1", "a3"]]}
```
`type ∈ {star, pipeline, mesh, hierarchical, blackboard}`. Это *разрешённая*
схема коммуникации; фактический граф сообщений может отличаться.

### `messages` (JSON list) — основной сигнал
```json
[{"t": 0, "from": "a1", "to": "a2", "type": "handoff",
  "intent": "request_quotes", "text": "a2, please take care of request_quotes ...",
  "tool": "", "refs": []},
 {"t": 1, "from": "a2", "to": "a1", "type": "inform",
  "intent": "request_quotes", "text": "Acknowledged, starting request_quotes.",
  "tool": "", "refs": []},
 {"t": 2, "from": "a2", "to": "a1", "type": "handoff",
  "intent": "request_quotes", "text": "request_quotes is done, artifact art_01 produced.",
  "tool": "", "refs": ["art_01"]}]
```

* `t` — порядковый номер хода (0-based, плотный, совпадает с индексом в списке);
* `type ∈ {handoff, inform, status, state_update, final, system}` — протокольный
  тип, он **не** кодирует класс сбоя;
* `handoff` без `refs` — это выдача задания, `handoff` с `refs` — это доставка результата;
* `intent` — обычно имя подзадачи; может быть пустым (потеря телеметрии);
* `refs` — ссылки на артефакты; могут быть срезаны;
* сообщения разных подзадач **перемешаны**, как при параллельной работе агентов;
  порядок внутри одной подзадачи сохранён.

### `artifacts` (JSON list)
```json
[{"id": "art_01", "by": "a2", "t": 2, "type": "quote_table",
  "subtask": "request_quotes", "hash": "3f9a12c0d4b1", "status": "final"}]
```
`status ∈ {final, partial, copy}`; одинаковый `hash` = побайтово тот же
результат; `subtask` может быть пустым.

### `shared_state` (JSON list) — журнал записей в общее состояние
```json
[{"t": 5, "agent": "a3", "key": "unit_price", "op": "set", "value": "820"},
 {"t": 9, "agent": "a4", "key": "unit_price", "op": "override", "value": "910"}]
```
Ключ `run_status` пишется командой самостоятельно и **не является** истинным
значением `success`.

## Целевые переменные (в `train.csv`)

| Колонка | Тип | Смысл |
|---|---|---|
| `label` | str | один из 7 классов, см. `docs/ontology.md` |
| `success` | 0/1 | достигнута ли бизнес-цель |
| `fault_turn` | int | ход, на котором начинается сбой; `-1` для `clean` |

## Шум и «грязная телеметрия»

Часть ранов приходит неполной — это сделано намеренно, чтобы решения были
устойчивыми:

* ~12 % ранов — все `intent` пустые;
* ~8 % — у половины сообщений вырезаны `refs`;
* ~10 % — у артефактов пустой `subtask`;
* ~15 % — часть текстов обрезана до 12–30 символов.

## Сдвиг распределения (для `Robustness F1`)

В test 33 % ранов сгенерированы вне обучающего распределения:
больше агентов (7–11 против 3–7), длиннее траектории (медиана 70 против 42
ходов), редкие топологии (`mesh`, `blackboard`), редкий домен
`compliance_audit`, другой набор формулировок и ролей. В train таких ранов
только 5 %.
